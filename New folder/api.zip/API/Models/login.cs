﻿using System;
using System.Collections.Generic;

namespace API.Models
{
    public partial class login
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
